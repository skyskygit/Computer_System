
#include <stdio.h>
#include <stdlib.h>
#include<sys/time.h>
#include<time.h>

void  main()
{


   struct timeval t1,t2,t3,t4;
    gettimeofday(&t1,0);
	
        int n=512;
    	int *a[n];
    	int *b[n];
    	int *c[n];
	     for(int i=0;i<n;i++)
    	{
    		a[i]=(int*)malloc(n*sizeof(int));
			b[i]=(int*)malloc(n*sizeof(int));
			c[i]=(int*)malloc(n*sizeof(int));
    	}

    	for(int i=0;i<n;i++)
    	{
    		for(int j=0;j<n;j++)
        	{
        	  a[i][j]=2;	
        	}
    	}
      gettimeofday(&t2,0);
    	for(int i=0;i<n;i++)
    	{
    		for(int j=0;j<n;j++)
        	{
    			for(int k=0;k<n;k++)
            	{
            	  c[i][j]=c[i][j]+a[i][k]*b[k][j];
            	}	
        	}
    	}
     gettimeofday(&t3,0);
    
            	
  gettimeofday(&t4,0);
  long program = t4.tv_sec-t1.tv_sec;
  long programM= t4.tv_usec-t1.tv_usec;
  long meet = t3.tv_sec - t2.tv_sec;
  long meetM = t3.tv_usec - t2.tv_usec;
  double d1 =program + programM*1e-6;
  double d2 =meet + meetM*1e-6;
  double praportion = d2/d1;
 
   
  printf("Total program time= %0.3f",d1);
  printf("\n");
  printf("Meat time= %0.3f",d2);
  printf("\n");
  printf("praportion = %0.3f",100*praportion);
  
}

